import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-auto',
  templateUrl: './auto.component.html',
  styleUrls: ['./auto.component.css'],
  moduleId: module.id,
})
export class AutoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
