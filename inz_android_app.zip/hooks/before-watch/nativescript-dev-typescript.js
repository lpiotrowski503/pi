module.exports = require("nativescript-dev-typescript/lib/watch.js");
